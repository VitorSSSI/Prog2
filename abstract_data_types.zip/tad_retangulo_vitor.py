#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  tad_retangulo_vitor.py
#  
#  Copyright 2019 Vitor Siqueira da Silva <vitor@Netbook-Vitor>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#---------------------------------------------------------------------
import tkinter

def intersec(retA,retB):
	primeiroX=0
	ultimoX=0
	aux=False
	primeiroY=0
	ultimoY=0
	pontosX_retA=list(range(retA[0],retA[2]+1))
	pontosY_retA=list(range(retA[1],retA[3]+1))
	pontosX_retB=list(range(retB[0],retB[2]+1))
	pontosY_retB=list(range(retB[1],retB[3]+1))
	for x in pontosX_retA:
		if x in pontosX_retB:
			if aux == False:
				primeiroX=x
				aux=True
			ultimoX=x
	aux=False
	for y in pontosY_retA:
		if y in pontosY_retB:
			if aux == False:
				primeiroY=y
				aux=True
			ultimoY=y
	return criar(primeiroX,primeiroY,ultimoX,ultimoY)

def mostrar(ret):
	cores=["blue","green","magenta","gray","purple"]
	root=tkinter.Tk()
	canvas=tkinter.Canvas(root,bg="khaki2",height=500,width=500)
	canvas.pack(fill=tkinter.BOTH,expand=True)
	if type(ret[0])==list:
		for posi,item in enumerate(ret):
			a=canvas.create_rectangle(item[0],item[1],item[2],item[3],fill=cores[posi],width=5)
	else:
		a=canvas.create_rectangle(ret[0],ret[1],ret[2],ret[3],fill="purple",width=5)
	root.mainloop()
	return None

def protetor(retA,retB,interAB):
	x1A=retA[0]
	x1B=retB[0]
	x1AB=interAB[0]
	x2A=retA[2]
	x2B=retB[2]
	x2AB=interAB[2]
	y1A=retA[1]
	y1B=retB[1]
	y1AB=interAB[1]
	y2A=retA[3]
	y2B=retB[3]
	y2AB=interAB[3]
	a=None
	cores=["blue","green","magenta","gray","purple"]
	root=tkinter.Tk()
	canvas=tkinter.Canvas(root,bg="khaki2",height=500,width=500)
	canvas.pack()
	A=canvas.create_rectangle(x1A,y1A,x2A,y2A,fill="purple")
	B=canvas.create_rectangle(x1B,y1B,x2B,y2B,fill="red")
	try:
		C=canvas.create_rectangle(x1AB,y1AB,x2AB,y2AB,fill="green")
	except:
		"Sem interseção"
	def move(ret,x):
		for p in range(len(ret)):
			ret[p]+=x
		return ret
	while True:
		for x in range(350):
			
			canvas.move(A,1,1)
			canvas.delete(C)
			retA=move(retA,1)
			interAB=intersec(retA,retB)
			if interAB[0]!=0 and interAB[1]!=0 and interAB[2]!=0 and interAB[3]!=0:
				x1AB=interAB[0]
				x2AB=interAB[2]
				y1AB=interAB[1]
				y2AB=interAB[3]
				C=canvas.create_rectangle(x1AB,y1AB,x2AB,y2AB,fill="green")
			canvas.after(3,canvas.update())
						
			canvas.move(B,-1,-1)
			canvas.delete(C)
			retB=move(retB,-1)
			interAB=intersec(retA,retB)
			if interAB[0]!=0 and interAB[1]!=0 and interAB[2]!=0 and interAB[3]!=0:
				x1AB=interAB[0]
				x2AB=interAB[2]
				y1AB=interAB[1]
				y2AB=interAB[3]
				C=canvas.create_rectangle(x1AB,y1AB,x2AB,y2AB,fill="green")
			canvas.after(3,canvas.update())
			
		for x in range(350):
			
			canvas.move(B,1,1)
			canvas.delete(C)
			retB=move(retB,1)
			interAB=intersec(retA,retB)
			if interAB[0]!=0 and interAB[1]!=0 and interAB[2]!=0 and interAB[3]!=0:
				x1AB=interAB[0]
				x2AB=interAB[2]
				y1AB=interAB[1]
				y2AB=interAB[3]
				C=canvas.create_rectangle(x1AB,y1AB,x2AB,y2AB,fill="green")
			canvas.after(3,canvas.update())
			
			canvas.move(A,-1,-1)
			canvas.delete(C)
			retA=move(retA,-1,)
			interAB=intersec(retA,retB)
			if interAB[0]!=0 and interAB[1]!=0 and interAB[2]!=0 and interAB[3]!=0:
				x1AB=interAB[0]
				x2AB=interAB[2]
				y1AB=interAB[1]
				y2AB=interAB[3]
				C=canvas.create_rectangle(x1AB,y1AB,x2AB,y2AB,fill="green")
			canvas.after(3,canvas.update())
			
	root.mainloop()
	return None
	
	
	
	
	
	
	
def criar(xse,yse,xid,yid):
	ret=[xse,yse,xid,yid]
	return ret
	
def get_largura(ret):
	larg=[ret[2]-ret[1]]
	return larg

def get_altura(ret):
	alt=[ret[3]-ret[1]]
	return alt
	
def get_esq_sup(ret):
	esqs=[ret[0],ret[1]]
	return esqs
	
def get_esq_inf(ret):
	esqi=[ret[0],ret[3]]
	return esqi
	
def get_dir_sup(ret):
	dirs=[ret[2],ret[1]]
	return dirs
	
def get_dir_inf(ret):
	diri=[ret[2],ret[3]]
	return diri
		
def pertence(ret,pt):
	x=pt[0]
	y=pt[1]
	if x>ret[0] and x<ret[2]:
		if y>ret[1] and y>ret[3]:
			return True
	return False
	
def contem(retA,retB):
	if len(quant_pertence(retA,retB))==4:
		return True
	return False
	
 

	
#teste
x=criar(50,0,150,100)
y=criar(400,400,500,500)
z=intersec(x,y)
protetor(x,y,z)	
