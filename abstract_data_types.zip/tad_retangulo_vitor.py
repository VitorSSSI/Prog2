#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  tad_retangulo_vitor.py
#  
#  Copyright 2019 Vitor Siqueira da Silva <vitor@Netbook-Vitor>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#---------------------------------------------------------------------
import tkinter


def mostrar(ret):
	cores=["blue","green","magenta","gray","purple"]
	root=tkinter.Tk()
	canvas=tkinter.Canvas(root,bg="khaki2",height=600,width=800)
	canvas.pack(fill=tkinter.BOTH,expand=True)
	if type(ret[0])==list:
		for posi,item in enumerate(ret):
			a=canvas.create_rectangle(item[0],item[1],item[2],item[3],fill=cores[posi],width=5)
	else:
		a=canvas.create_rectangle(ret[0],ret[1],ret[2],ret[3],fill="purple",width=5)
	root.mainloop()
	return None
	
def criar(xse,yse,xid,yid):
	ret=[xse,yse,xid,yid]
	return ret
	
def get_largura(ret):
	larg=[ret[2]-ret[1]]
	return larg

def get_altura(ret):
	alt=[ret[3]-ret[1]]
	return alt
	
def get_esq_sup(ret):
	esqs=[ret[0],ret[1]]
	return esqs
	
def get_esq_inf(ret):
	esqi=[ret[0],ret[3]]
	return esqi
	
def get_dir_sup(ret):
	dirs=[ret[2],ret[1]]
	return dirs
	
def get_dir_inf(ret):
	diri=[ret[2],ret[3]]
	return diri
		
def pertence(ret,pt):
	x=pt[0]
	y=pt[1]
	if x>ret[0] and x<ret[2]:
		if y>ret[1] and y>ret[3]:
			return True
	return False
	
def quant_pertence(retA,retB):
	pontos=[get_esq_inf(retA),get_esq_sup(retA),get_dir_inf(retA),get_dir_sup(retA)]
	saida=[None,None,None,None]
	for x in range(4):
		if pertence(retB,pontos[x]):
			saida[x]=pontos[x]
	return saida
	
	
def contem(retA,retB):
	if len(quant_pertence(retA,retB))==4:
		return True
	return False
	
 
def intersec(retA,retB):
	
#Para A contido em B	
	
	lstpertence = quant_pertence(retA,retB)
	if contem(retA,retB):
		return retB

#Para A com um vértice em B
	if len(lstpertence)==1:
		for x,y in enumerate(lstpertence):
			if x!=None:
				ponto=[y,x]
		if ponto[1] == 0:
			
			xsup_esq=ponto[0]
			xsup_esq=xsup_esq[0]
			
			ysup_esq=get_dir_sup(retB)
			ysup_esq=ysup_esq[1]
			
			xinf_dir=get_dir_sup(retB)
			xinf_dir=xinf_dir[0]
			
			yinf_dir=ponto[0]
			yinf_dir=yinf_dir[1]
			
			return criar(xsup_esq,ysup_esq,xinf_dir,yinf_dir)
						
		if ponto[1]==1:
						
			xsup_esq=ponto[0]
			xsup_esq=xsup_esq[0]
			
			ysup_esq=ponto[0]
			ysup_esq=ysup_esq[1]
			
			xinf_dir=get_dir_inf(retB)
			xinf_dir=xinf_dir[0]
			
			yinf_dir=get_dir_inf(retB)
			yinf_dir=yinf_dir[1]
			
			return criar(xsup_esq,ysup_esq,xinf_dir,yinf_dir)
			
		if ponto[1]==2:
			
						
			xsup_esq=get_esq_sup(retB)
			xsup_esq=xsup_esq[0]
			
			ysup_esq=get_esq_sup(retB)
			ysup_esq=ysup_esq[1]
			
			xinf_dir=ponto[0]
			xinf_dir=xinf_dir[0]
			
			yinf_dir=ponto[0]
			yinf_dir=yinf_dir[1]
			
			return criar(xsup_esq,ysup_esq,xinf_dir,yinf_dir)
			
		if ponto[1]==3:
			
						
			xsup_esq=get_esq_inf(retB)
			xsup_esq=xsup_esq[0]
			
			ysup_esq=ponto[0]
			ysup_esq=ysup_esq[1]
			
			xinf_dir=ponto[0]
			xinf_dir=xinf_dir[0]
			
			yinf_dir=get_esq_inf(retB)
			yinf_dir=yinf_dir[1]
			
			return criar(xsup_esq,ysup_esq,xinf_dir,yinf_dir)
#Para A com dois vértices em B			
