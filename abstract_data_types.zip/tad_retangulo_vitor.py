#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  tad_retangulo_vitor.py
#  
#  Copyright 2019 Vitor Siqueira da Silva <vitor@Netbook-Vitor>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#----------------------------------------------------------------------
import tkinter as tk


def mostrar(ret):
	top=tk.TK()
	canvas==tk.Canvas(top,bg="khaki2",height=600,width=800)
	canvas.pack(fill=tk.BOTH,expand=True)
	top.mainloop()
	return None
	
def criar(xse,yse,xid,yid):
	ret=[xse,yse,xid,yid]
	return ret
	
def get_largura(ret):
	larg=ret[2]-ret[1]
	return larg

def get_altura(ret):
	alt=ret[3]-ret[1]
	return alt
	
def get_esq_sup(ret):
	esqs=ret[0],ret[1]
	return esqs
	
def get_esq_inf(ret):
	esqi=ret[0],ret[3]
	return esqi
	
def get_dir_sup(ret):
	dirs=ret[2],ret[1]
	return dirs
	
def get_dir_inf(ret):
	diri=ret[2],ret[3}
	return diri
		
def pertence(ret,pt):
	x=pt[0]
	y=pt[1]
	if x>ret[0] and x<ret[2]:
		if y>ret[1] and y>ret[3]:
			return True
	return False
	
def _quant_pertence(retA,retB):
	pontos=[get_esq_inf(retA),get_esq_sup(retA),get_dir_inf(retA),get_dir_sup(retA)]
	saida=[None,None,None,None]
	for x in range(4):
		if pertence(retB,pontos[x]):
			saida[x]=pontos[x]
	return saida
	
	
def contem(retA,retB):
	if quant_pertence(retA,retB)==4:
		return True
	return False
	
 
def intersec(retA,retB):
	lstpertence = _quant_pertence(retA,retB)
	if contem(retA,retB):
		print("Retângulo A está contido no retãngulo B")
		return None
	if len(lstpertence)==1:
		for x in lstpertence:
			if x!=None:
				ponto=x
	
			
			
		
