#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  tad_retangulo_vitor.py
#  
#  Copyright 2019 Vitor Siqueira da Silva <vitor@Netbook-Vitor>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#---------------------------------------------------------------------
import tkinter
import random

def move(ret,x):
	for p in range(len(ret)):
		ret[p]+=x
	return ret

def intersec(retA,retB):
	#inicialização de variáveis:
	primeiroX=0
	ultimoX=0
	primeiroY=0
	ultimoY=0
	aux=False
	
	#Salvamos aqui o range entre o x superior esquerdo e o x inferior direito
	pontosX_retA=list(range(retA[0],retA[2]+1))
	pontosY_retA=list(range(retA[1],retA[3]+1))
	pontosX_retB=list(range(retB[0],retB[2]+1))
	pontosY_retB=list(range(retB[1],retB[3]+1))
	
	#Descobre o primeiro e último "x" iguais entre os dois retângulos
	for x in pontosX_retA:
		if x in pontosX_retB:
			if aux == False:
				primeiroX=x
				aux=True
			ultimoX=x
	aux=False
	
	#Descobre o primeiro e último "y" iguais entre os dois retângulos
	for y in pontosY_retA:
		if y in pontosY_retB:
			if aux == False:
				primeiroY=y
				aux=True
			ultimoY=y
			
	return criar(primeiroX,primeiroY,ultimoX,ultimoY)
#Fim intersec

def mostrar(ret):
	cores=["blue","green","magenta","gray","purple"]
	root=tkinter.Tk()
	canvas=tkinter.Canvas(root,bg="khaki2",height=500,width=500)
	canvas.pack(fill=tkinter.BOTH,expand=True)
	if type(ret[0])==list:
		for posi,item in enumerate(ret):
			a=canvas.create_rectangle(item[0],item[1],item[2],item[3],fill=cores[posi],width=5)
	else:
		a=canvas.create_rectangle(ret[0],ret[1],ret[2],ret[3],fill="purple",width=5)
	root.mainloop()
	return None
#Fim mostrar


def criar(xse,yse,xid,yid):
	ret=[xse,yse,xid,yid]
	return ret
#Fim criar
	
def get_largura(ret):
	larg=[ret[2]-ret[1]]
	return larg
#Fim get_largura

def get_altura(ret):
	alt=[ret[3]-ret[1]]
	return alt
#Fim get_altura
	
def get_esq_sup(ret):
	esqs=[ret[0],ret[1]]
	return esqs
#Fim get_esq_sup
	
def get_esq_inf(ret):
	esqi=[ret[0],ret[3]]
	return esqi
#Fim get_esq_inf
	
def get_dir_sup(ret):
	dirs=[ret[2],ret[1]]
	return dirs
#Fim get_dir_sup
	
def get_dir_inf(ret):
	diri=[ret[2],ret[3]]
	return diri
#Fim get_dir_inf
		
def pertence(ret,pt):
	x=pt[0]
	y=pt[1]
	if x>ret[0] and x<ret[2]:
		if y>ret[1] and y>ret[3]:
			return True
	return False
#Fim pertence

def contem(retA,retB):
	if len(quant_pertence(retA,retB))==4:
		return True
	return False
#Fim contem
	
	
#TESTE
x=criar(100,0,300,150)
y=criar(300,350,500,500)
z=intersec(x,y)
protetor(x,y,z)	
