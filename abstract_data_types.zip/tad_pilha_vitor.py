#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  tad_pilha_vitor.py
#  
#  Copyright 2019 Vitor Siqueira da Silva <vitor@Netbook-Vitor>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  
def criar():
	return []
#fim criar

def empilhar(p,v):
	p.append(v)
	return p
#fim empilhar

def desempilhar(p):
	if not vazia(p):
		return p.pop()
	return None
#fim retirar

def vazia(p):
	return len(p) == 0
#fim vazia
	
def topo(p):
	if not vazia(p):
		return p[-1]
	return None
#fim topo



	
